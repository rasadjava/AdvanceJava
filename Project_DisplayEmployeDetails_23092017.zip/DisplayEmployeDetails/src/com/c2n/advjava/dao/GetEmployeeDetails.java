package com.c2n.advjava.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.c2n.advjava.beans.Employee;

public class GetEmployeeDetails {
	public static Connection getDataSoure() {
		Connection con = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/advance_java_jsp", "root", "admin");
		System.out.println("############ Database Connected ###############");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return con;
	}

	public static List<Employee> getEmployeeList() {
		List<Employee> empList = new ArrayList<Employee>();
		Connection con = getDataSoure();
		try {
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("select * from jsp_emp");
			System.out.println("############ Received Data Database ###############");
			while (rs.next()) {
				Employee emp = new Employee();
				emp.setId(rs.getInt(1));
				emp.setName(rs.getString(2));
				emp.setTech(rs.getString(3));
				emp.setSalary(rs.getFloat(4));
				emp.setMobile(rs.getInt(5));
				empList.add(emp);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return empList;
	}
}
