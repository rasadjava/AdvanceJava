package com.c2n.advjava.jsp.custom;

import java.io.IOException;
import java.net.InetAddress;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.TagSupport;

public class JSPCustomTagHandler extends TagSupport {
	
	public int doStartTag() throws JspException {
		
		JspWriter out = pageContext.getOut();
		String str = "Prasad999000";
		try {
			InetAddress iAddress = InetAddress.getLocalHost();
			//String sssss=iAddress.getHostAddress();
			out.print(iAddress.getHostAddress());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return SKIP_BODY;
	}

}
